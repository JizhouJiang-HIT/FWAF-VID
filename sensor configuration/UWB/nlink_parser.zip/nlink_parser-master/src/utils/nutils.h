#ifndef NUTILS_H
#define NUTILS_H

void TopicAdvertisedTip(const char *topic);

#endif // NUTILS_H
