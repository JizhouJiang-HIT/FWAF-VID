#ifndef INITSERIAL_H
#define INITSERIAL_H
#include <serial/serial.h>

void initSerial(serial::Serial *serial);

#endif // INITSERIAL_H
